MediStock — Bulk Demo Inventory
================================

This package adds 83 sample inventory records to your existing MediStock MongoDB database.

IMPORTANT
- The names, manufacturers, batch numbers, prices, quantities and expiry dates are demo data.
- Do not use these records for real dispensing, purchasing or patient-care decisions.
- The script does not delete records and does not overwrite existing records.
- It uses your existing backend/.env file and the MONGODB_URI inside it.
- If you run it more than once, it skips the same MED-1001 ... MED-1083 IDs.

HOW TO INSTALL
1. Stop neither MongoDB nor your project permanently; MongoDB must be running.
2. Copy backend/seed-demo-data.js from this package into your existing project’s backend folder.
3. Open your existing backend folder in VS Code.
4. Open the VS Code terminal in the backend folder (the folder that contains server.js and package.json).
5. Run:
       node seed-demo-data.js
6. Wait for a message saying how many records were added.
7. Refresh http://localhost:5173.

Your existing backend/.env should remain in place. The script defaults to:
       mongodb://127.0.0.1:27017/medistock

If your existing database uses a different MONGODB_URI, the script will use that URI from .env.

The demo data includes some low-stock items and some expiry dates within 90 days so that you can demonstrate alerts.
